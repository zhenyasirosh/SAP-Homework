sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		formatRadioButton: function(sValue) {
			return (sValue !== null) ? parseInt(sValue, 10) - 1 : -1;
		},

		formatCreatedByField: function(sCreatedBy, dDateCreation) {
			var dDateCreationFormated = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "YYYY.MM.dd"
			}).format(dDateCreation);

			var dDateCreationRelative = sap.ui.core.format.DateFormat.getDateInstance({
				relative: "true",
				relativeRange: "[-25;25]"
			}).format(dDateCreation);

			// return sCreatedBy + " " + formatedDate;
			var deleteLAB =
				`${this.getModel("i18n").getResourceBundle().getText("ItemsCreatedByAndDate")} ${sCreatedBy} ${this.getModel("i18n").getResourceBundle().getText("ItemsCreatedOnDate")} ${dDateCreationFormated} (${dDateCreationRelative})`;
			return deleteLAB.split('LAB').join('')
		},

		formatModifiedByField: function(sModifiedBy, dDateModification) {
			var dDateModificationFormated = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "YYYY.MM.dd"
			}).format(dDateModification);

			var dDateModificationRelative = sap.ui.core.format.DateFormat.getDateInstance({
				relative: "true",
				relativeRange: "[-25;25]"
			}).format(dDateModification);

			var deleteLAB = `${this.getModel("i18n").getResourceBundle().getText("ItemsModifiedByAndDate")} ${sModifiedBy} ${this.getModel("i18n").getResourceBundle().getText("ItemsModifiedOnDate")} ${dDateModificationFormated} (${dDateModificationRelative})`;
			return deleteLAB.split('LAB').join('')
		}

	};

});